Pyticks - IN PORTUGUESE!!

Obrigado por testar o Pyticks!

Como rodar:
- Certifique-se de ter Java 17 ou superior instalado
- Dê dois cliques no arquivo Pyticks.jar

Se não abrir:
- Clique com botão direito > Abrir com > Java
OU
- Execute pelo CMD:
  java -jar Pyticks.jar

Controles:
- Add: cria bloco
- Delete: remove bloco
- Anchor: trava/destrava bloco
- Colors: muda cor
- Move / Resize / Scale: ferramentas

Salvar/Carregar:
- Save: salva mundo
- Load: carrega mundo

Observações:
- Esta é uma versão inicial (Pre-Classic)
- Bugs são esperados

Versão: Pre-Classic 0.1